#include <stdint.h>
#include "soc_AM335x.h"
#include "hw_types.h"

#define SOC_PRCM_REGS 						(0x44E00000)
#define SOC_CM_PER_REGS 					(SOC_PRCM_REGS + 0)
#define CM_PER_GPIO1_CLKCTRL 					(0xAC)
#define CM_PER_GPIO1_CLKCTRL_MODULEMODE_ENABLE			(0x2u)
#define CM_PER_GPIO1_CLKCTRL_OPTFCLKEN_GPIO_1_GDBCLK 		(0x00040000u)

#define SOC_CONTROL_REGS 					(0x44E10000)
#define CM_conf_gpmc_a5 					(0x0848)

#define SOC_GPIO_1_REGS 					(0x4804C000)
#define GPIO_OE 						(0x134)
#define GPIO_SETDATAOUT 					(0x194)
#define GPIO_CLEARDATAOUT 					(0x190)

#define TOGGLE 							(0x01u) // Definição do TOGGLE
unsigned int flagBlink; // Inicialização do flagBlink

// FUNÇÃO LEDINIT
void ledInit() {
    unsigned int val_temp;

    // Configura o clock do GPIO no módulo do clock
    HWREG(SOC_CM_PER_REGS + CM_PER_GPIO1_CLKCTRL) |= (CM_PER_GPIO1_CLKCTRL_MODULEMODE_ENABLE |
    CM_PER_GPIO1_CLKCTRL_OPTFCLKEN_GPIO_1_GDBCLK);

    // Configura mux do pino no módulo de controle
    HWREG(SOC_CONTROL_REGS + CM_conf_gpmc_a5) |= 7;

    // Define a direção do pino
    val_temp = HWREG(SOC_GPIO_1_REGS + GPIO_OE);
    val_temp &= ~(1 << 21); // Configura o pino 21 como saída
    HWREG(SOC_GPIO_1_REGS + GPIO_OE) = val_temp;
}

// FIM DA FUNÇÃO LEDINIT

void ledToggle() {
    
    flagBlink ^= TOGGLE;
    
    if (flagBlink){
        HWREG(SOC_GPIO_1_REGS + GPIO_SETDATAOUT) = (1 << 21);}
    else{
        HWREG(SOC_GPIO_1_REGS + GPIO_CLEARDATAOUT) = (1 << 21);}
}
//FUnção atraso

void delay(volatile unsigned int count){
	while(count--);
}

// FIM DA FUNÇÃO LEDTOGGLE

int main(void) {
	flagBlink = 0;
    ledInit(); // Configura o LED verde e controla o pino

    while (1) {
        ledToggle(); // Muda o status do LED verde
        delay(100000); // Pausa por 500 milissegundos
    }
    return 0;
}
