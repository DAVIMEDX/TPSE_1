#include "hw_types.h"
#include "soc_AM335x.h"

#define TIME                                            100000000000
#define TOGGLE                                          (0x01u)

//FUNÇÃO WT
#define WDT_WSPR					0x44E35048 
#define WDT_WWPS					0x44E35034

// Definindo a ativação do clock.
#define SOC_PRCM_REGS		                            (0x44E00000)
#define SOC_CM_PER_REGS		                            (SOC_PRCM_REGS + 0)

#define CM_PER_GPIO1_CLKCTRL                            0xAC
#define CM_PER_GPIO1_CLKCTRL_MODULEMODE_ENABLE	        (0x2u)
#define CM_PER_GPIO1_CLKCTRL_OPTFCLKEN_GPIO_1_GDBCLK	(0x00040000u)

// Definindo a configuração do MUX.
#define CM_conf_gpmc_a5                                 0x0854
#define CM_conf_gpmc_a6                                 0x0858
#define CM_conf_gpmc_a7                                 0x085C
#define CM_conf_gpmc_a8                                 0x0860
#define CM_conf_gpmc_be1n                               0x878
#define CM_conf_gpmc_a0					0x840
#define CM_conf_gpmc_a1                                 0x844

// Definição da direção do pino.
#define GPIO_OE                                         0x134
#define GPIO_CLEARDATAOUT                               0x190
#define GPIO_SETDATAOUT                                 0x194
#define GPIO_DATAIN                                     0x138



unsigned int flagBlink0;

static void delay();
static void ledInit();
static void ledToggle0();
static int buttonPressed();
static void initButton();
//Desabilita o "watchdog"
void disableWdt(){
	HWREG(WDT_WSPR) = 0xAAAA;
	while(HWREG(WDT_WWPS) & (1<<4));
	HWREG(WDT_WSPR) = 0x5555;
	while(HWREG(WDT_WWPS) & (1<<4));
}


int main(void) {

	disableWdt();
    	flagBlink0 = 0;
    	ledInit_0();
    	ledInit_1();
    	initButton_0();
    	initButton_1();
    	
    while(1) {
       button_0_Pressed();
       button_1_Pressed();
    }
    return (0);
}

void delay(volatile unsigned int count) {
    while (count--);
}

void ledInit_0() {
    unsigned int val_temp;
    HWREG(SOC_CM_PER_REGS+CM_PER_GPIO1_CLKCTRL) |= CM_PER_GPIO1_CLKCTRL_OPTFCLKEN_GPIO_1_GDBCLK | CM_PER_GPIO1_CLKCTRL_MODULEMODE_ENABLE;
    HWREG(SOC_CONTROL_REGS+CM_conf_gpmc_a5)|= 7;
    HWREG(SOC_CONTROL_REGS+CM_conf_gpmc_a6)|= 7;
    HWREG(SOC_CONTROL_REGS+CM_conf_gpmc_a7)|= 7;
    HWREG(SOC_CONTROL_REGS+CM_conf_gpmc_a8)|= 7;
   
  //Ativação dos mux dos leds interno e do led externo;//
//////////////////////////////////////////////////////////
    val_temp = HWREG(SOC_GPIO_1_REGS+GPIO_OE);
    val_temp &= ~(1<<21);
    val_temp &= ~(1<<22);
    val_temp &= ~(1<<23);
    val_temp &= ~(1<<24);
    HWREG(SOC_GPIO_1_REGS+GPIO_OE) = val_temp;
    
     
  //Setando os bits correspondentes a ativação dos leds com "0";//
//////////////////////////////////////////////////////////
}

void ledInit_1() {
    unsigned int val_temp;
    HWREG(SOC_CM_PER_REGS+CM_PER_GPIO1_CLKCTRL) |= CM_PER_GPIO1_CLKCTRL_OPTFCLKEN_GPIO_1_GDBCLK | CM_PER_GPIO1_CLKCTRL_MODULEMODE_ENABLE;
    HWREG(SOC_CONTROL_REGS+CM_conf_gpmc_be1n)|= 7;

   
  //Ativação dos mux dos leds interno e do led externo;//
//////////////////////////////////////////////////////////
    val_temp = HWREG(SOC_GPIO_1_REGS+GPIO_OE);
    val_temp &= ~(1<<28);
   
    HWREG(SOC_GPIO_1_REGS+GPIO_OE) = val_temp;
    
     
  //Setando os bits correspondentes a ativação dos leds com "0";//
//////////////////////////////////////////////////////////
}

void initButton_0(){
    unsigned int val_temp;
    HWREG(SOC_CM_PER_REGS+CM_PER_GPIO1_CLKCTRL) |= CM_PER_GPIO1_CLKCTRL_OPTFCLKEN_GPIO_1_GDBCLK | CM_PER_GPIO1_CLKCTRL_MODULEMODE_ENABLE;
    HWREG(SOC_CONTROL_REGS+CM_conf_gpmc_a0) |= 7;
    
     //Configurando a ativação do botão;//
//////////////////////////////////////////////////////////
    val_temp=(SOC_CONTROL_REGS+GPIO_OE);
    val_temp |= (1<<16);
    HWREG(SOC_CONTROL_REGS+GPIO_OE) = val_temp;


}

void initButton_1(){
    unsigned int val_temp;
    HWREG(SOC_CM_PER_REGS+CM_PER_GPIO1_CLKCTRL) |= CM_PER_GPIO1_CLKCTRL_OPTFCLKEN_GPIO_1_GDBCLK | CM_PER_GPIO1_CLKCTRL_MODULEMODE_ENABLE;
    HWREG(SOC_CONTROL_REGS+CM_conf_gpmc_a1) |= 7;
    
     //Configurando a ativação do botão;//
//////////////////////////////////////////////////////////
    val_temp=(SOC_CONTROL_REGS+GPIO_OE);
    val_temp |= (1<<17);
    HWREG(SOC_CONTROL_REGS+GPIO_OE) = val_temp;


}

int button_0_Pressed(){
    
    if((HWREG(SOC_GPIO_1_REGS+GPIO_DATAIN) & (1<<16)) != 0) {
    	ledToggle0();
    }
}
int button_1_Pressed(){
    
    if((HWREG(SOC_GPIO_1_REGS+GPIO_DATAIN) & (1<<17)) != 0) {
    	ledToggle1();
    }
}
void ledToggle0(volatile unsigned int i){
    flagBlink0 ^= TOGGLE;

    if(flagBlink0) {
        HWREG(SOC_GPIO_1_REGS+GPIO_SETDATAOUT) = 1<<(21);
        HWREG(SOC_GPIO_1_REGS+GPIO_SETDATAOUT) = 1<<(22);
        HWREG(SOC_GPIO_1_REGS+GPIO_SETDATAOUT) = 1<<(23);
        HWREG(SOC_GPIO_1_REGS+GPIO_SETDATAOUT) = 1<<(24);
    } else {
        HWREG(SOC_GPIO_1_REGS+GPIO_CLEARDATAOUT) = 1<<(21);
        HWREG(SOC_GPIO_1_REGS+GPIO_CLEARDATAOUT) = 1<<(22);
        HWREG(SOC_GPIO_1_REGS+GPIO_CLEARDATAOUT) = 1<<(23);
        HWREG(SOC_GPIO_1_REGS+GPIO_CLEARDATAOUT) = 1<<(24);
    }
}

void ledToggle1(volatile unsigned int i){
    flagBlink0 ^= TOGGLE;

    if(flagBlink0) {
        HWREG(SOC_GPIO_1_REGS+GPIO_SETDATAOUT) = 1<<(28);
        
    } else {
        HWREG(SOC_GPIO_1_REGS+GPIO_CLEARDATAOUT) = 1<<(28);
    }
}



      ///////////////////////////////////////////////////////////   
//Função para condicionar a ativação ou desativação dos leds correspondeste//
      //////////////////////////////////////////////////////////
